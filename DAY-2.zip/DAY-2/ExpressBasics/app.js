const express = require("express");
const app = express();
const port = 3000;

app.get("/", (req, res) => {
  //   res.send("Hello World!");
  // res.sendFile("Index.html", { root: __dirname });
  let products = [
    { id: 1, title: "Macbook Pro", price: 250000 },
    { id: 2, title: "Macbook Air", price: 200000 },
  ];
  res.json(products);
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
