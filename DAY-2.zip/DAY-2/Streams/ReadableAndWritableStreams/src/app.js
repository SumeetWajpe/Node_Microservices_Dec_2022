const fs = require("fs");

const readableStream = fs.createReadStream("Input.txt");
const writeableStream = fs.createWriteStream("Output.txt");

let dataToBeWritten = "";

// readableStream.on("data", chunk => {
//   console.log("\n\r>>>>>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>>>>>>>>>> \n\r");
//   // console.log(chunk.toString());
//   dataToBeWritten += chunk.toString();
// });

// readableStream.on("end", () => {
//   writeableStream.write(dataToBeWritten);
//   writeableStream.end();
// });

// OR

readableStream.pipe(writeableStream);
