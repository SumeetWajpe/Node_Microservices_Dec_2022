const express = require("express");
const router = express.Router();
let orders = [
  { id: 1, products: ["LEDTV", "Laptop"] },
  { id: 2, products: ["Watch", "Shoes"] },
];
router.get("/", (req, res) => {
  res.json(orders);
});

module.exports = router;
