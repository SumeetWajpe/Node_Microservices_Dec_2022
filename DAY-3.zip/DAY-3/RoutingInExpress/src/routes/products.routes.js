const express = require("express");
const router = express.Router();
let products = [
  { id: 1, title: "Macbook Pro", price: 250000 },
  { id: 2, title: "Macbook Air", price: 200000 },
];
router.get("/", (req, res) => {
  res.json(products);
});

router.post("/newproduct", (req, res) => {
  console.log("Add a new product here..");
  res.json({ msg: "product added successfully !" });
});

router.get("/details/:id", (req, res) => {
  let productId = +req.params.id; // parseInt
  let theProduct = products.find(p => p.id === productId);
  res.json(theProduct);
});

module.exports = router;
