const express = require("express");
const app = express();

const productsRouter = require("./routes/products.routes");
const ordersRouter = require("./routes/orders.routes");

const port = 3000;

// built-in middleware
app.use(express.static("src/static"));
app.get("/", (req, res) => {
  //   res.send("Hello World!");
  res.sendFile("Index.html", { root: __dirname });
});
app.use("/products", productsRouter);
app.use("/orders", ordersRouter);

//* - should be placed at the last after all endpoints are defined !
app.use((req, res) => {
  // ErrorPage.html
  res.status(404).send("Resource not found !");
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
