const express = require("express");
const indexRouter = require("./routes/index");
const app = express();
const path = require("path");
const port = 3000;

// view engine set up
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");
// routes
app.use("/", indexRouter);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
