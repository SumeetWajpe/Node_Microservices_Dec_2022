const router = require("express").Router();

router.get("/", (req, res) => {
  // res.send("Using Pug !");
  res.render("index", { title: "Using Pug !!!" });
});

module.exports = router;
