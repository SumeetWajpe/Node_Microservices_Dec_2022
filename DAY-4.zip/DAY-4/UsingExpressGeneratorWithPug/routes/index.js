var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  let products = [
    { id: 1, title: "Macbook Pro", price: 250000 },
    { id: 2, title: "Macbook Air", price: 200000 },
  ];
  res.render("index", { title: "Using Express", products });
});

module.exports = router;
