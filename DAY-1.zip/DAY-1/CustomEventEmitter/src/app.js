// publisher
const EventEmitter = require("events").EventEmitter;
function GetCount(maxCount) {
  let e = new EventEmitter();

  process.nextTick(() => {
    e.emit("start");
    let counter = 0;
    let t = setInterval(() => {
      if (counter < maxCount) {
        e.emit("count", counter++);
      }
      if (counter == maxCount) {
        e.emit("done", counter);
        clearInterval(t);
      }
      if (counter >= 8) {
        e.emit("error", counter);
        clearInterval(t);
      }
    }, 500);
  });

  return e;
}

// subscriber

const evt = GetCount(10);
evt.on("start", () => {
  console.log("Starting iteration !");
});
evt.on("count", currCount => {
  console.log(`The current count : ${currCount}`);
});
evt.on("done", currCount => {
  console.log(`Done with current count : ${currCount}`);
});
evt.on("error", currCount => {
  console.log(`Done with Error & current count : ${currCount}`);
});
