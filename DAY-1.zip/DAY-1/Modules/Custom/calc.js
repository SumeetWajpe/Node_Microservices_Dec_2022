const math = require("./math");
console.log(`The addition is ${math.Add(20, 30)}`);
