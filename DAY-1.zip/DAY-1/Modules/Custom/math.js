function Add(x, y) {
  return x + y;
}

function Product(x, y) {
  return x * y;
}

// module.exports.Addition = Add;
// module.exports.Product = Product;

module.exports = { Add, Product };
