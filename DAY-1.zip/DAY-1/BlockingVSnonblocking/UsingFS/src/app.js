const fs = require("fs");

try {
  const dataFromTheFile = fs.readFileSync("Input.txt", { encoding: "utf-8" });
  console.log(dataFromTheFile);
} catch (error) {
  console.log(error);
}
console.log("Program Ended !");

//==================================================
// Async/Non-Blocking way of reading files
// const fs = require("fs");

// fs.readFile("Input.txt", (err, data) => {
//   if (err) {
//     console.log(err);
//   } else {
//     console.log(data.toString());
//   }
// });

// console.log("Program Ended !");
